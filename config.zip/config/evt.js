import { appSounds, SystemPrefs, pop, popCountries, Swiper, thousandsSeperator, Notif, footerBottomCustomText } from '../assets/js/utils.js'
import Tagify from '../assets/plugins/tagify-master/dist/tagify.esm.js';

const notif = new Notif(),
      systemPrefs = new SystemPrefs(),
      clients = [
        {name: `Ghana Armed Forces Institute`, logo: '../assets/img/clientele/GAFI Supermarket.jpeg'},
        {name: `Allure Pharmacy`, logo: ''},
        {name: `Mama Mary Maternity Clinic`, logo: ''},
        {name: `Koful Medical Center`, logo: ''},
        {name: `Blessed RJ Enterprise`, logo: ''},
        {name: `Kuta Enterprise`, logo: ''},
        {name: `Final-mini Supermarket`, logo: ''},
        {name: `Kuta Enterprise`, logo: ''},
        {name: `3y3no Enterprise`, logo: ''},
        {name: `KrunchyCreme Restaurant`, logo: '../assets/img/clientele/KrunchyCreme_Logo.jpg'},
        {name: `Nana's Daily Groceries`, logo: '../assets/img/clientele/NanasDailyGroceries.jpeg'},
        {name: `Rashmall Ventures`, logo: ''},
        {name: `Emek Consult Services`, logo: ''},
        {name: `Glalims Enterprise`, logo: ''},
        {name: `S.S Hina Enterprise`, logo: ''},
        {name: `E.S.P Transport`, logo: ''},
        {name: `L-J Ventures`, logo: ''},
        {name: `Madina Supermarket`, logo: ''},
        {name: `Mirian Ventures`, logo: ''},
        {name: `Masaks Ventures`, logo: ''},
        {name: `Kalamazoo Hill Restauturant`, logo: '../assets/img/clientele/Kalamazoo Restaurant.jpeg'},
        {name: `Pinam Mart`, logo: '../assets/img/clientele/pinam mart.jpeg'},
        {name: `Glalims Annex`, logo: ''},
        {name: `Ask Madina Coldstore`, logo: ''},
        {name: `Ask Ameh Coldstore`, logo: ''},
      ]

const popCurrencies = () => {
    $.post(`./crud.php?prefs&currencies`, null, resp => {
        console.log(resp)
        tableCurrencies.setData(resp.data);
    }, 'json');
}
// let rateFactorTag = new Tagify(
//     document.querySelector(`#rateFactorTags_${currency_id}`), 
//     // `#rateFactorTags_${currency_id}`,
//     {
//         placeholder: 'enter rate factors',
//         delimiters: ",",           
//     }
// );

let tableCurrencies = new Tabulator("#currencies-table", {
    // width: '100%',
    height: 250,
    width: 300,          //load row data from array
    layout: "fitColumns",      //fit columns to width of table
    cellVertAlign: "middle",
    responsiveLayout: "collapse",  //hide columns that dont fit on the table    
    // movableColumns: true,  
    // resizableColumns: true,
    tooltips: true,            //show tool tips on cells
    // addRowPos: "top",          //when adding a new row, add it to the top of the table
    history: true,             //allow undo and redo actions on the table        
    initialSort: [             //set the initial sort order of the data
        // {column: "CAT", dir: "asc"},
        {column: "name", dir: 'asc'},
    ],
    index: 'currency_id',
    selectable: 1,
    selectableCheck: row => {
        //row - row component
        // return row.getData().emp_id != undefined; //allow selection of rows where the age is greater than 18
    },
    columns: [
        {title: '#', field: '', formatter: 'rownum', width: 50},
        {title: 'Code', field: 'code', editor: 'input', editorParams: {}, validator: ['required'], width: 80},
        {title: 'Symbol', field: 'symbol', editor: 'input', editorParams: {}, formatter: (cell, formatterParams, onRendered) => cell.getValue() && he.decode(cell.getValue()), validator: ['required'], width: 90},
        {title: 'Name', field: 'title', editor: 'input', editorParams: {}, formatter: (cell, formatterParams, onRendered) => cell.getValue() && he.decode(cell.getValue()), validator: ['required'], minWidth: 120},
        {title: 'Exch. Rate', field: 'exch_rate', editor: 'number', editorParams: { min: 0, step: .01 }, width: 120 },
        {title: 'Rate Factor', field: 'factor', editor: "input", width: 120 },
        {title: 'Places', field: 'places', editor: "select", editorParams: {
            listItemFormatter: (value, title) => title,
            values: [0, 1, 2, 3], //create list of values from all values contained in this column
            sortValuesList: "asc", //if creating a list of values from values:true then choose how it should be sorted
            // defaultValue: "Steve Johnson", //set the value that should be selected by default if the cells value is undefined
            elementAttributes: { maxlength: "10", },
            verticalNavigation: "hybrid", //navigate to new row when at the top or bottom of the selection list
            // multiselect: true, //allow multiple entries to be selected
        }, width: 80},
        {title: 'Format', field: '', formatter: (cell, formatterParams, onRendered) => cell.getData().currency_id && new Intl.NumberFormat('en-US', { currency: cell.getData().code, minimumFractionDigits: cell.getData().places }).format(123456789), width: 130},
        {title: '', field: 'is_default', editor: true, formatter: 'tickCross', editable: cell => cell.getData().is_default == 0, sorter: 'boolean', hozAlign: 'center', width: 50}
    ],
    // groupHeaderDownload,
    tooltipsHeader: true, //enable header tooltips
    tooltipGenerationMode: "hover", //regenerate tooltip as users mouse enters the cell;
    cellEditing: cell => {
        //cell - cell component
        // cell.getField() == "qty_wh" ? cell.setValue("") : '';
    },
    cellEditCancelled: cell => {
        //cell - cell component
        if(!cell.isEdited()){
            // cell.getOldValue() != "" ? cell.setValue(cell.getInitialValue() - cell.getOldValue()) : cell.restoreInitialValue();
            // cell.clearvalidator();
        }
    },
    cellEdited: cell => {
        //cell - cell component
        let { new_record, currency_id, code, symbol, places, is_default } = cell.getData();
        new_record && cell.getTable().validate()
        // console.log((cell.getData()), cell.getValue());

        if(cell.isValid() && _.size(cell.getTable().getInvalidCells()) < 1){
            $.post(`./crud.php?prefs&currencies&update`, {currency_id, col: cell.getField(), value: cell.getValue()}, resp => {
            // $.post(`./crud.php?prefs&currencies`, {cellData: JSON.stringify(cell.getData())}, resp => {
                console.log(resp)
                if (resp.saved || resp.updated) {
                    appSounds.oringz.play();
                    alertify.success(resp.saved && "Saved" || 'Updated.');
                    popCurrencies();
                }
                // tableCurrencies.setData(_.map(resp, country => ({code: country.currency_symbol})));
            }, 'json');
        }
    },
    validatorFailed: (cell, value, validators) => {
        //cell - cell component for the edited cell
        //value - the value that failed validator
        //validatiors - an array of validator objects that failed
        // console.log(cell, value, validators);
    },
    rowFormatter: row => {
        // console.log(row.getCell('emp_id').getValue(), row.getPosition() == 0 && row.getCell('emp_id').setValue(10000));
        // row.getData()['emp_id'] == undefined && row.getElement().classList.add('new-record');
        // console.log(row.getData());
    },
    pagination: "local",       //paginate the data
    paginationSize: 100,         //allow 7 rows per page of data
    paginationButtonCount: 2,
    printAsHtml: true, //enable html table printing
    printStyled: true, //copy Tabulator styling to HTML table
    printRowRange: "all",
    printFooter: `<div style="display: flex; justify-content: space-between; align-items: center;"><p><b>Powered By</b>: MyshopOS v0.7</p><p><b>Visit</b>: www.myshopos.com</p></center>`,
    placeholder: "No Data Available", //display message to user on empty table
});

const pageTapSwiper = new Swiper('.swiper#pageTapSwiper', {
    // direction: 'vertical',
    speed: 400,
    autoHeight: true,
    allowTouchMove: false,
    simulateTouch: false,
    pagination: {
        el: '.swiper#pageTapSwiper .swiper-pagination',
        type: 'bullets',
        clickable: true,
        bulletElement: 'button',
        bulletActiveClass: 'activeTab',
        slidesPerView: 'auto',
        renderBullet: (index, className) => {
            // console.log(className);
            let tabs = [{title: 'Company', icon: 'home'}, {title: 'Preferences', icon: 'wrench'}, {title: 'About', icon: 'info-circle'}];
            return `<button type="button" class="tabs ${className}"><i class="fa fa-${tabs[index].icon} fa-2x"></i><br/> ${tabs[index].title}</button>`;
        },
    },
    on: {
        init: () => {
            // console.log('swiper initialized');
        },
        slideChange: swiper => {
            console.log('slide changed', swiper.activeIndex);
            if(swiper.activeIndex == 1){               
                popCurrencies();
            }
            else if(swiper.activeIndex == 2){
                _.map(clients, client => {
                    $('#clients').append(`
                        <div class="cl-2 cm-3 cs-4 cx-6 txt-center">
                            <div class="form-group">
                                <img src="${client.logo == "" ? `../assets/img/myshopos_logo.png` : client.logo}" alt="${client.name} logo" width="70" height="70">
                                <br/>
                                <small>${client.name}</small>
                            </div>
                        </div>
                    `);
                });
                $('#licensee').html(_.startCase($("#company_name").val()))
                $('#subscription_plan').html(`Standard <span style="margin: 0 10px; color: gray;">|</span> <a href="" class="clr-info">Upgrade</a>`)
                $('#payment_method').html(`Bank Transfer`)
                let lastRenewal = moment($("#frm-crud-company-setup [type='submit']").data('regdate')).format("YYYY-MM-DD"),
                    nextRenewal = moment($("#frm-crud-company-setup [type='submit']").data('regdate')).add(1, 'Y');
                $('#plan_days_left').html(`${nextRenewal.format("ll")} <span style="margin: 0 10px; color: gray;">|</span> <b>${moment().diff(moment(nextRenewal), 'days')} days</b> (${moment.duration(-moment().diff(nextRenewal, 'days'), 'days').humanize(true)})`)
            }
            // console.log(moment.duration(-moment().diff('2023-06-15', 'days'), 'days').humanize(true))
        },
        resize: swiper => {
            // console.log('resized');
        }
    },
}),
clienteleSwiper = new Swiper('.swiper#clienteleSwiper', {
    speed: 400,
    // spaceBetween: 100,
    // navigation: false,
    slidesPerView: 2,
    autoplay: {
        delay: 5000,
        // disableOnInteraction: false,
        pauseOnFocus: false,
    },
    // nested: true,
    pagination: {
        el: '.swiper#clienteleSwiper .swiper-pagination',
        type: 'bullets',
        clickable: true,
    },
});

// console.log($("#companySetup").height(), document.body.offsetHeight);

// loop through all the swiper slides and add some padding to the bottom of each one to make the content is always visible
const setSwiperPadding = () => {
    let swiperSlides = $('.swiper-slide');
    swiperSlides.each((index, element) => {
        let swiperSlide = $(element);
        let swiperSlideHeight = swiperSlide.height();
        // console.log(swiperSlideHeight);
        if((swiperSlideHeight + 50) >= document.body.offsetHeight) {
            swiperSlide.css('padding-bottom', '70px');
        }
    });
};
setSwiperPadding();

let oldFileName;
const popCompanyInfo = () => {
    $.ajax({
        url: "crud.php?pop",
        type: "post",
        dataType: 'JSON',
        success: resp => {
            console.log(resp.data)
            if (resp.data != 0) {
                $("#frm-crud-company-setup [type='submit']").removeClass('btn-primary new').addClass('btn-success update').html("<i class='fa fa-pencil'></i> Update").attr({'data-comp-id': resp.data[0].comp_id, 'data-regdate': resp.data[0].regdate});
                $("#company_regdate").val(resp.data[0].company_regdate);
                pond.addFile(`../uploads/${resp.data[0].logo}`);
                oldFileName = resp.data[0].logo;
                $("#company_name").val(resp.data[0].comp_name);
                $("#phone").val(resp.data[0].phone);
                $("#mobile").val(resp.data[0].mobile);
                $("#email").val(resp.data[0].email);
                $("#fax").val(resp.data[0].fax);
                $("#website").val(resp.data[0].website);
                $("#addr").val(resp.data[0].addr);
            }
            else {
                $("#frm-crud-company-setup [type='submit']").removeClass('btn-success update').addClass('btn-primary new').html("<i class='fa fa-save'></i> Save").removeAttr('data-comp-id');
            }
            $("#frm-crud-company-setup input, textarea, select").prop('disabled', false);
            $("#frm-crud-company-setup [type='submit']").prop('disabled', false);
        },
        beforeSend: () => {
            $("#frm-crud-company-setup input:not(#company_logo), textarea, select").prop('disabled', true);
            $("#frm-crud-company-setup [type='submit']").html("<i class='fa fa-spinner fa-spin'></i>").prop('disabled', true);
        }
    });
}
popCompanyInfo();

// We register the plugins required to do 
// image previews, cropping, resizing, etc.
FilePond.registerPlugin(
    FilePondPluginFileValidateType,
    FilePondPluginImageExifOrientation,
    FilePondPluginImagePreview,
    FilePondPluginImageCrop,
    FilePondPluginImageResize,
    FilePondPluginImageTransform,
    FilePondPluginImageEdit
);

// Select the file input and use 
// create() to turn it into a pond
let pond = FilePond.create(
    document.querySelector('input[type="file"]#company_logo'),
    {
        labelIdle: 'Drag & Drop company logo or <span class="filepond--label-action"> Browse </span>',
        imagePreviewHeight: 170,
        imageCropAspectRatio: '1:1',
        imageResizeTargetWidth: 200,
        imageResizeTargetHeight: 200,
        stylePanelLayout: 'compact circle',
        styleLoadIndicatorPosition: 'center bottom',
        styleProgressIndicatorPosition: 'right bottom',
        styleButtonRemoveItemPosition: 'left bottom',
        styleButtonProcessItemPosition: 'right bottom',
        // required: true,
        credits: false,
        checkValidity: true,
        dropvalidator: true,
        onaddfilestart: file => {
            $("#frm-crud-company-setup [type='submit']").prop('disabled', true);
        },
        onaddfile: file => {
            
        },
        onerror: (file, status) => {
            // console.log(file);
            file.main == 'File is of invalid type' && alert(`${file.main}\nOnly png, jpeg or jpg files are supported.`);
            if(file.code == 404){
                alert("File not found!");
                pond.removeFile();
                $("#frm-crud-company-setup [type='submit']").prop('disabled', false);
            }
        },
        onprocessfile: (error, file) => {
            // console.log(error, file);
            $("#frm-crud-company-setup [type='submit']").prop('disabled', false);
        },
        server: {
            url: './crud.php',
            // process: (fieldName, file, metadata, load, error, progress, abort, transfer, options) => {
                // console.log(file)
            //     console.log(fieldName, file, metadata, load, error, progress, abort, transfer, options)
            //     var formData = new FormData(), req = new XMLHttpRequest();
            //     formData.append(fieldName, file, file.name);
            //     req.open('POST', './crud.php');
            //     req.onload = e => {
            //         console.log(req.status)
            //     }
            //     req.send(formData);
            // }
        }
    }
);

$(document).on('submit', "#frm-crud-company-setup", function(e){
    let formData = new FormData(this);                
    if(pond.getFile() == null){
        alert("You have not uploaded a logo.\nThis will default to the logo for this app.");
        pond.addFile('../assets/img/myshopos_logo.png');
    }
    else{
        formData.append('file', pond.getFile()['file'], pond.getFile()['file']['filename']);
        $.ajax({
            url: `./crud.php?${$("#frm-crud-company-setup [type='submit']").hasClass('new') && 'new' || `update&editCompanyID=${$("#frm-crud-company-setup [type='submit']").data('compId')}&editOldFileName=${oldFileName}`}`,
            type: "POST",
            dataType: 'json',
            data: formData,
            cache: false,
            contentType: false,
            processData: false,
            success: resp => {
                // console.log(resp);
                if (resp.saved || resp.updated) {
                    appSounds.oringz.play();
                    alertify.success(resp.saved && "Saved" || 'Updated.');
                    $("#frm-crud-company-setup")[0].reset();
                    popCompanyInfo();
                }
                else {
                    console.log(resp);
                }
                $("#frm-crud-company-setup [type='submit']").html("<i class='fa fa-save'></i> Save").prop('disabled', false);
                $("#frm-crud-company-setup input, textarea, select").prop('disabled', false);
            },
            beforeSend: function () {
                $("#frm-crud-company-setup [type='submit']").html("<i class='fa fa-spinner fa-spin'></i>").prop('disabled', true);
                $("#frm-crud-company-setup input, textarea, select").prop('disabled', true);
            }
        });
    }
    return false;
}); 

let footerBottomCustomTextEditor = footerBottomCustomText({height: 200});

$("#voucherDate").val(moment().format('YYMMDD'));

// const tablePaymentTypes = new Tabulator("#paymentTypes-table", {
//     width: 300,
//     height: 200,
//     layout: "fitColumns",
//     placeholder: "No Data Set",
//     movableRows: true,
//     addRowPos: "top",
//     headerVisible: false,
//     data: [
//         {title: "Cash", notes: ""},
//         {title: "Mobile Money", notes: ""},
//         {title: "POS", notes: ""},
//         {title: "Credit", notes: ""},
//     ],
//     columns: [
//         { rowHandle: true, formatter: "handle", headerSort: false, frozen: true, width: 30, minWidth: 30, },
//         // { title: "#", formatter: 'rownum', headerSort: false, align: "right", width: 40 },
//         { title: "PAYMENT_TYPE ID", field: 'pm_id', visible: false },
//         { title: "TITLE", field: "title", editor: 'input', hozAlign: "left", formatter: (cell, formatterParams, onRendered) => _.toUpper(cell.getValue()), width: 150 },
//         // { title: "DESCRIPTION", field: "notes", editor: 'input', headerSort: false, hozAlign: "left" },
//         {title: "", field: "", width: 30, headerSort: false, hozAlign: "center", tooltip: "Delete", formatter: (cell, formatterParams, onRendered) => { return "<i class='fa fa-check fa-2x' onclick=''></i>" || ''; }, print: false, cellClick: (e, cell) => {
            
//         }},
//     ],
//     rowMoved: (row) => {
//         console.log(row);
//     },
//     cellEdited: cell => {
//         if(cell.isValid()){
//             let row = cell.getRow();
//             let data = row.getData();
//             data.notes = cell.getValue();
//             row.update(data);
//         }
//     }
// });
// tablePaymentTypes.addRow({});

// const popPaymentTypes = () => {
//     $.get(`./crud.php?prefs&pop`, null, resp => {
//         console.log(resp);
//     }, 'json');
// }
// popPaymentTypes();

let vat, discount, receiptPref;
const PREFS = () => systemPrefs.pop()
.then(config => {
    // tableCurrencies.setData([{new_record: true}, ...JSON.parse(he.decode(config.data[4].pref))]);
    // tableCurrencies.setData(JSON.parse(he.decode(config.data[4].pref)));
    // console.log(JSON.parse(config.data[4].pref));
    vat = JSON.parse(config.data[0].pref)['vat'];
    discount = JSON.parse(config.data[0].pref)['discount'];
    receiptPref = config.data[1].pref && JSON.parse((config.data[1])?.pref);
    if(_.size(_.keys(receiptPref)) > 0){
        $(`#vat`).val(he.decode(vat.rate));
        $(`#vatType`).val(he.decode(vat.type))
        $(`#discount`).val(he.decode(discount.rate))
        $(`#discountType`).val(he.decode(discount.type));
        $(`#vat_discount_apply_rule`).prop('checked', vat.before == 1)
        $(`#prefix`).val(he.decode(receiptPref.code.prefix));
        $(`#stickerVisibility`).prop('checked', receiptPref.sticker.visibility == 1)
        $(`[name="stickerType"][value="${_.toLower(receiptPref.sticker.type)}"]`).eq(0).prop('checked', true);
        $(`[name="stickerPosition"][value="${_.toLower(receiptPref.sticker.position)}"]`).eq(0).prop('checked', true);
        $(`#borderStyle option:contains(${he.decode(receiptPref.border.style)})`).eq(0).prop('selected', true);
        $("#borderDepth").val(he.decode(receiptPref.border.depth));
        $(`[name="borderColor"][value="${he.decode(receiptPref.border.color)}"]`).prop("checked", true);
        $(`[name="backgroundColor"][value="${he.decode(receiptPref.background.color)}"]`).prop("checked", true);
        $("#fontSize").val(he.decode(receiptPref.font.size));
        $(`#fontFamily option:contains(${he.decode(receiptPref.font.family)})`).eq(0).prop('selected', true);
        footerBottomCustomTextEditor.setHTML(he.decode(receiptPref.footer.bottom));
    }
});
PREFS();

// console.log(he.decode(CONFIG.receiptPref.footer))
$(document).on('blur', "#custom_receipt_footer_text", e => {
    if(receiptPref.footer.bottom != he.encode(footerBottomCustomTextEditor.getHTML())){
        let { module, pref } = JSON.parse(e.target.parentElement.dataset.pref);
        systemPrefs.update(module, pref, he.encode(footerBottomCustomTextEditor.getHTML()))
        .then(resp => {
            if(resp.updated){
                appSounds.oringz.play();
                alertify.success("Receipt Footer Updated");
                PREFS();
            }
            else{
                console.error(resp.data);     
            }
        })
        .catch(err => console.error("Oopss... ", err));
    }
});

$(document).on('change', "#vat, #discount", e => e.target.value = !e.target.value ? 0 : e.target.value);

const fontCheck = new Set([
    // Windows 10
    'Arial', 'Arial Black', 'Bahnschrift', 'Calibri', 'Cambria', 'Cambria Math', 'Candara', 'Comic Sans MS', 'Consolas', 'Constantia', 'Corbel', 'Courier New', 'Ebrima', 'Franklin Gothic Medium', 'Gabriola', 'Gadugi', 'Georgia', 'HoloLens MDL2 Assets', 'Impact', 'Ink Free', 'Javanese Text', 'Leelawadee UI', 'Lucida Console', 'Lucida Sans Unicode', 'Malgun Gothic', 'Marlett', 'Microsoft Himalaya', 'Microsoft JhengHei', 'Microsoft New Tai Lue', 'Microsoft PhagsPa', 'Microsoft Sans Serif', 'Microsoft Tai Le', 'Microsoft YaHei', 'Microsoft Yi Baiti', 'MingLiU-ExtB', 'Mongolian Baiti', 'MS Gothic', 'MV Boli', 'Myanmar Text', 'Nirmala UI', 'Palatino Linotype', 'Segoe MDL2 Assets', 'Segoe Print', 'Segoe Script', 'Segoe UI', 'Segoe UI Historic', 'Segoe UI Emoji', 'Segoe UI Symbol', 'SimSun', 'Sitka', 'Sylfaen', 'Symbol', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana', 'Webdings', 'Wingdings', 'Yu Gothic',
    // macOS
    'American Typewriter', 'Andale Mono', 'Arial', 'Arial Black', 'Arial Narrow', 'Arial Rounded MT Bold', 'Arial Unicode MS', 'Avenir', 'Avenir Next', 'Avenir Next Condensed', 'Baskerville', 'Big Caslon', 'Bodoni 72', 'Bodoni 72 Oldstyle', 'Bodoni 72 Smallcaps', 'Bradley Hand', 'Brush Script MT', 'Chalkboard', 'Chalkboard SE', 'Chalkduster', 'Charter', 'Cochin', 'Comic Sans MS', 'Copperplate', 'Courier', 'Courier New', 'Didot', 'DIN Alternate', 'DIN Condensed', 'Futura', 'Geneva', 'Georgia', 'Gill Sans', 'Helvetica', 'Helvetica Neue', 'Herculanum', 'Hoefler Text', 'Impact', 'Lucida Grande', 'Luminari', 'Marker Felt', 'Menlo', 'Microsoft Sans Serif', 'Monaco', 'Noteworthy', 'Optima', 'Palatino', 'Papyrus', 'Phosphate', 'Rockwell', 'Savoye LET', 'SignPainter', 'Skia', 'Snell Roundhand', 'Tahoma', 'Times', 'Times New Roman', 'Trattatello', 'Trebuchet MS', 'Verdana', 'Zapfino',
].sort());
  
(async() => {
    await document.fonts.ready;

    const fontAvailable = new Set();

    for (const font of fontCheck.values()) {
        if (document.fonts.check(`12px "${font}"`)) {
            fontAvailable.add(font);
        }
    }
    // Append the list of available fonts to the fonts select picker.
    [...fontAvailable.values()].map(font => {
        // $(`#fontFamily`).append(`<option ${_.toLower(font) == "verdana" ? 'selected' : ''}>${font}</option>`);
        $(`#fontFamily`).append(`<option value="${_.upperFirst(font)}">${_.upperFirst(font)}</option>`);
    });    
})();

$(document).on('change', "#fontFamily", function(e){
    $(`#fontPreview`).css('font-family', e.target.value);
});

$(document).on('change', "#preferences input, #preferences select, #preferences textarea", function(e){
    // console.log(_.size($(e.target).parent('.tabulator-cell.tabulator-editing')))
    if(_.size($(e.target).closest('.tabulator-cell')) < 1){
        let { module, pref } = $(e.target).data('pref');
        systemPrefs.update(module, pref, he.encode(e.target.value))
        .then(resp => {
            if(resp.updated){
                appSounds.oringz.play();
                alertify.success("Receipt Footer Updated");
                PREFS();
            }
            else{
                console.error(resp.data);     
            }
        })
        .catch(err => console.error("Oopss... ", err));
    }
});

$(document).on('click', "#db_backup", function(e){
    $.post(`./crud.php?database&backup`, {dbName: "myshoposdb_backup.sql"}, resp => {
        console.log(resp);
        // if(resp.updated){
        //    appSounds.oringz.play();
        //     resp.saved ? alertify.success("Updated") : console.error(resp.data);     
        // }
    }, 'json');
});

